export class Note {
  constructor(
      public note: string = '',
  ) {}
}
