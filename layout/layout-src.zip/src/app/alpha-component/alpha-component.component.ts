import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alpha-component',
  templateUrl: './alpha-component.component.html',
  styleUrls: ['./alpha-component.component.css']
})
export class AlphaComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
