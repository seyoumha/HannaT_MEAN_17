import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamma-component',
  templateUrl: './gamma-component.component.html',
  styleUrls: ['./gamma-component.component.css']
})
export class GammaComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
