import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beta-component',
  templateUrl: './beta-component.component.html',
  styleUrls: ['./beta-component.component.css']
})
export class BetaComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
